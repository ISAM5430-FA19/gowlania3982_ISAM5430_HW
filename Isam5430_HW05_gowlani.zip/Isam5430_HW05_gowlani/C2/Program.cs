﻿using System;

namespace C2
{
    class Program
    {
        static void Main(string[] args)
        {
            Motorway motorway = new Motorway("Toyota",true,3,"East");
            Console.WriteLine($"the name of motorway is:{motorway.GetName_motorway()}");
        }
    }
}
