﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int a=1;a<=5;a++)
            {
                for(int b=a+1;b<=5;b++)
                {
                    Console.WriteLine(a + " " + b + " ");
                }
            }
        }
    }
}
