﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_6
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Enter a integer");
            string n = ReadLine();
            int num = Convert.ToInt32(n);
            int rev = 0;
            //to check if n is a positive number
            while(num>0)
            {
                rev = (rev*10) +num % 10;
                num = num / 10;
               
            }
            WriteLine(rev);
        }
    }
}
