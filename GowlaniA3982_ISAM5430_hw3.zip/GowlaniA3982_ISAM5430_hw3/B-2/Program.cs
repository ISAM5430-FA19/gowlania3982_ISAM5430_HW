﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_2
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("enter the integers ");
            string n = ReadLine();
            int prevnum;
            int sum = 0;
          
            while(true)
            {
                prevnum = Convert.ToInt32(n);
                sum += prevnum;
                n = ReadLine();

                if (n.Length == 0)
                {
                    WriteLine("the sum is : " + sum);
                    break;
                }
               if (Convert.ToInt32(n)==prevnum)
               {
                    WriteLine("the sum is : " + sum);
                    break;
               }
             
            }
        }
    }
}

