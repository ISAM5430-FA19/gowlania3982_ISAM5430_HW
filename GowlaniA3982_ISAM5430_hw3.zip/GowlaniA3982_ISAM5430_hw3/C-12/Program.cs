﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_12
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Enter a number:");
            int n = Convert.ToInt32(ReadLine());
            WriteLine("Prime numbers are:");
            int count = 0;
            int i = 0;
            while(count<n)
            {
                if(i%1==2)
                {
                    WriteLine(i);
                    count++;
                }

            }
            i++;


        }
    }
}
