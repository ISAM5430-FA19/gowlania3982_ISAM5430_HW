﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GowlaniA3982_Hw_04
{
    class Program
    {
        static void Main(string[] args)
        {
            for (int a = 1; a <= 5; a++)
            {
                for (int b = 1; b <= 5; b++)
                {
                   
                       Console. WriteLine(a+" " +b);
                    
                    //S WriteLine(a + " " + b + " ");



                }
            }
        }
    }
}
