﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2b
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            int sum1 = 0;
            //for 2 numbers 
            for (int a = 1; a <= 5; a++)
            {
                for (int b = a + 1; b <= 5; b++)
                {
                    Console.WriteLine(a + " " + b + " ");
                    sum = sum + a * b;
                }
            }
            Console.WriteLine("the sum is:" + sum);
            //3 number
            for (int a = 1; a <= 5; a++)
            {
                for (int b = a + 1; b <= 5; b++)
                {
                    for (int c = b + 1; c <= 5; c++)
                    {

                        Console.WriteLine(a + " " + b + " " + c + " ");
                        sum1 = sum1 + (a * b * c);


                    }
                }
            }
            Console.WriteLine("the sum is :" + sum1);

        }
    }
}
