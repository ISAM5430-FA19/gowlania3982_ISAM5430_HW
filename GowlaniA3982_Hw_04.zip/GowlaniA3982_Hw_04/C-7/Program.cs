﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_7
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("enter the characters:");
            int vowelcounter = 0;
            int concounter = 0;
            while(true)
            {
                var c = Console.ReadKey();
                char letter = char.ToUpperInvariant(c.KeyChar);
                if(!char.IsLetter(letter))
                {
                    break;
                }
                if (letter == 'A' || letter == 'E' || letter == 'I' ||letter=='O'||letter=='U')
                {
                    vowelcounter++;
                }
                else
                {
                    concounter++;
                }
            }
            WriteLine("\n");
            WriteLine("the vowel count is :" + vowelcounter);
            WriteLine("the consonant count is:" + concounter);




        }
    }
}
