﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9_a
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("enter the characters:");
            var c = Console.ReadKey();
            char letter = char.ToUpperInvariant(c.KeyChar);
            int prevchar = letter;
            
            while(true)
            {
                c = Console.ReadKey();
                 letter = char.ToUpperInvariant(c.KeyChar);
                if (!char.IsLetter(letter))
                {
                    break;
                }
               else if(letter<prevchar)
                {
                    break;
                    WriteLine("not in increasing order:");
                   


                }
               
            }
           
        }
    }
}
