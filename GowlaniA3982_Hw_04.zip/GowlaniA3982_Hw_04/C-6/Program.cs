﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_6
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Enter the characters:");
            //var keyInfo = Console.ReadKey();
            int counter = 0;
            while (true)
            {
                var keyInfo = Console.ReadKey();
                counter++;
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!(char.IsLetter(letter)))
                {
                    WriteLine("\n");
                    WriteLine("The count is :" + counter);
                    break;
                }




            }

        }
    }
}
