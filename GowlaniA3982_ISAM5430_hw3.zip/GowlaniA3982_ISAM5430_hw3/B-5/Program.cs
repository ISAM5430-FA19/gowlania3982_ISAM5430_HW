﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_5
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("enter the item");
            int item = Convert.ToInt32(ReadLine());
            int diff = 0;
            
            while (true)
            {
               
                string num = ReadLine();
              
                if(num==null)
                {
                    break;
                }
                if(Convert.ToInt32(num)==item)
                {
                    WriteLine("the difference is "+diff);
                    break;
                    

                }
                diff = Convert.ToInt32(num) - item;

            }

        }
    }
}
