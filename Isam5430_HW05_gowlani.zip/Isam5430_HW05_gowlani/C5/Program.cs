﻿using System;

namespace C5
{
    class Program
    {
        static void Main(string[] args)
        {
            Date date = new Date(10, 10, 2019);
            date.DisplayDate();
            
       }
    }
}
