﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("Enter the characters:");
            //var keyInfo = Console.ReadKey();
          
            while (true)
            {
                var keyInfo = Console.ReadKey();
                
                char letter = char.ToUpperInvariant(keyInfo.KeyChar);
                if (!(char.IsLetter(letter)))
                {
                   
                    break;
                }
                   
                
               

            }
            
           // WriteLine("the count is :");
            


        }
    }
}
