﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C1
{
    class Student
    {
        public int student_number;
        private string firstname;
        private string lastname;
        private decimal GPA = 0.0m;
        private string _major;

        public Student(decimal gpa)
        {
            GPA = gpa;
        }
        //properties
        public string Firstname
        {
            get
            {
                return firstname;
            }
            set
            {
                firstname = value;
            }
        }
        public decimal Gpa
        {
            get
            {
                return GPA;
            }
            set
            {
                GPA = value;
            }
        }
        public Student(string Firstname)
        {
            firstname = Firstname;
        }
        public void SetFirstname(string FN)
        {
            firstname = FN;
        }
        public string GetFirstname()
        {
            return firstname;
        }

        //public void Setgpa(float Gpa)
        //{
        //    GPA = Gpa;
        //}
        //public float Getgpa()
        //{
        //    return GPA;
        //}

    }
}

    

