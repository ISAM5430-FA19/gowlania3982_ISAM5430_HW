﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B1
{
    class Program
    {
        static void Main(string[] args)
        {
          //  int sum = 0;
            for(int a=1;a<=5;a++)
            {
                for(int b=1;b<=5;b++)
                {
                   if(a!=b)
                    {
                        WriteLine(a + " " + b + " "+ " ");
                        //sum += a * b;
                    }
                       //S WriteLine(a + " " + b + " ");
                    
                   

                }
            }
           // WriteLine("The sum is : " + sum);
        }
    }
}
