﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C2
{
    class Motorway
    {
        private string name_motorway;
        private string type;
        private string Direction;
        private string surface;
        private int no_of_lanes;
        private Boolean toll;
        private string party;

        //creating contructors
        public Motorway(string Name_motorway, bool toll, int lanes, string direction)
        {
            toll = true;
            no_of_lanes = lanes;
            Direction = direction;
            name_motorway = Name_motorway;
        }
        //create methods
        public void SetName_motorway(string NM)
        {
            name_motorway = NM;
        }
        public string GetName_motorway()
        {
            return name_motorway;
        }

        public Motorway(int No_of_lanes)
        {
            no_of_lanes = No_of_lanes;
        }
        //create methods
        public void SetNo_of_lanes(int NL)
        {
            no_of_lanes = NL;
        }
        public int  GetFirstname()
        {
            return no_of_lanes;
        }
        public Motorway(Boolean Toll)
        {
            toll = Toll;
        }
        public void SetToll(Boolean T)
        {
            toll= T;
        }
        public Boolean GetToll()
        {
            return toll;
        }


    }
}
