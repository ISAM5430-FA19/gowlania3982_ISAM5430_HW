﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_4
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("enter the sides:");
            int i = 0;
            while(true)
            {
                int a = 0;
                int b = 0;
                int c = 0;
                String s = ReadLine();
                int n = Convert.ToInt32(s);
                i++;
                if(s==null)
                {
                    break;
                }
                if(n<=0)
                {
                    WriteLine("Cannot enter zero or negative numbers:");
                    break;

                }
                if(i==1)
                {
                    a = n;
                }
                if(i==2)
                {
                    b = n;
                }
                if(i==3)
                {
                    c = n;
              
                    if (a + b > c)
                    {
                        WriteLine("valid triangle");
                    }
                    else if (a + c > b)
                    {
                        WriteLine("valid triangle");
                    }
                    else if (b + c > a)
                    {
                        WriteLine("valid triangle");
                    }

                }


            }
        }
    }
}
