﻿using System;

namespace Isam5430_HW05_gowlani
{
    class Program
    {
        static void Main(string[] args)
        {
            Student student = new Student("Aashna");
            Student gpa = new Student(3.3m);
            Console.WriteLine($"the name is : { student.Firstname}");
            Console.WriteLine($"the GPA is : { student.Gpa}");
        }
    }
}
