﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _14_c
{
    class Program
    {

        static void Main(string[] args)
        {
            WriteLine("Enter the number of rows:");
            int row = Convert.ToInt32(ReadLine());
            for(int i=1;i<=row;i++)
            {
                for (int j = 1; j <= row; j++)
                {
                    if (j < i)
                    {
                        Write('-');
                    }
                    else
                    {
                        Write('*');
                    }

                }
                WriteLine("\n");
            }
               
            }
        }
    }

