﻿using System;

namespace C1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            Student student = new Student("Aashna");
            Student gpa = new Student(3.3m);
            Console.WriteLine($"the name is : { student.Firstname}");
            Console.WriteLine($"the GPA is : { student.Gpa}");
        }
    }
}
