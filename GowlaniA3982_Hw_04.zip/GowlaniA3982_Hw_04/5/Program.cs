﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5
{
    class Program
    {
        static void Main(string[] args)
        {
           
            for (char a = 'A'; a <= 'H'; a++)
            {
                
                for (char b = 'A'; b <= 'H'; b++)
                {
                    if (a == 'A' || a == 'B' && b != 'A' || b != 'E')
                    {
                       
                        Console.WriteLine(a + " " + b + "");
                    }


                    for (char c = 'A'; c <= 'H'; c++)
                    {
                        
                        
                            Console.WriteLine(a + " " + b + " " + c + " ");
                        
                        
                    }
                }
            }
        }
    }
}
