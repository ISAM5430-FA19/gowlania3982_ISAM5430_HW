﻿using System;
using System.Collections.Generic;

namespace ISAM5430.FA19.HW08
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");
            //created a new dictionary here
            Dictionary<string, string> dict = new Dictionary<string, string>();
            //two ways to use dict
            dict.Add("First", "Aashna");
            dict["Last"] = "Gowlani";
            // dict["First"] = "Aash";// this to midfy the first name 
            Console.WriteLine("My first name is " + dict["First"]);
            Console.WriteLine($"My last name is {dict["Last"]}"); //lower case l will not work
                                                                  //key that doesnt exist gives runtime error
                                                                  // Console.WriteLine($"My last name is {dict["last"]}");
            if (dict.ContainsKey("last"))
            {
                Console.WriteLine($"My last name is {dict["last"]}");
            }
            else
            {
                Console.WriteLine("key last not found ");
            }
            string lastName;
            //if key last exists in dict then set the last name to be the value associated to the key upon returning a true; or else return false
            if (dict.TryGetValue("Last", out lastName))
            {
                Console.WriteLine($"My last name is {lastName}");
            }
            //to remove a key
            dict.Remove("Last");
            //to get all the keys
            var keys = dict.Keys;
            //this gives us all the keys 
            Console.WriteLine(string.Join(",", keys));



            //iterating theough a dict
            dict["Email"] = "gowlaniaashna@gmail.com";
            dict["Addresss"] = "16100 space center blvd";
            dict["City"] = "Houston";
            foreach (KeyValuePair<string, string> kvp in dict)
            {
                Console.WriteLine($"{kvp.Key,-10} {kvp.Value}");
                string value = kvp.Value;
                value = dict[kvp.Key]; //alterante method
                                       //you cannot do this in for each loop in collection
                                       // dict.Remove("address"); <-- not allowed.

            }
            string octal = "12345670";
                foreach(var c in octal)
            {
                if(OctalToBiNary.ContainsKey(c))
                {
                    Console.Write(OctalToBiNary[c]);
                }
            }
        }
        private static readonly Dictionary<char, string> OctalToBiNary = new Dictionary<char, string>
        {
            {'0',"000" },
            {'1',"001" },
            {'2',"010" },
            {'3',"011" },
            {'4',"100" },
            {'5',"101" },
            {'6',"110" },
            {'7',"111" }

        };
    }
}
