﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_1
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("enter the integers");
           // int n = Convert.ToInt32(ReadLine());
            int sum = 0;
            int avg = 0;
            int count = 0;
            int max = 0;
           
            while (true)
            {
                String n = ReadLine();
              
                if(n.Length == 0)
                {
                    WriteLine("Not a vallid score.");
                    break;
                }

                else if (Convert.ToInt32(n) <0 || Convert.ToInt32( n )>100)
                {
                    break;
                }

                else
                {
                    int num = Convert.ToInt32(n);

                    sum = sum + num;
                    count++;
                    if (num>max)
                    {
                        max = num;
                    }
                }
            }
            avg = sum / count;
            WriteLine(avg);
            WriteLine(max);

        }
    }
}
