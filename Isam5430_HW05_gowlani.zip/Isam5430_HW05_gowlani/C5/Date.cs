﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C5
{
    class Date
    {
        //setting get set in curly braces means you are creating propperty
        int Day { get; set; }
        int Month {get; set;}
        int Year { get; set; }

        //constructor
        public Date(int day, int month,int year)
        {
            Day = day;
            Month = month;
            Year = year;
        }

        public void DisplayDate()
        {
            Console.WriteLine(Month + "/" + Day + "/" + Year);
        }

    }
}
