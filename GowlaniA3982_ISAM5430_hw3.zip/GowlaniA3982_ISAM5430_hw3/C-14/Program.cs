﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_14
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;
            WriteLine("display the pattern:");
            WriteLine("enter the no of rows:");
            int row = Convert.ToInt32(ReadLine());
            for(i=1;i<=row;i++)
            {
                for( j=1;j<=i;j++)
                {
                    Write('*');
                   // WriteLine("\n");
                   
                }
                WriteLine("\n");
            }
            WriteLine("display the pattern:");
            WriteLine("enter the no of rows:");
            int row1 = Convert.ToInt32(ReadLine());
            for (i = row; i>=1; i--)
            {
                for (j = 1; j<=i; j++)
                {
                    Write('*');
                    // WriteLine("\n");

                }
                WriteLine("\n");
            }
        }
    }
}
