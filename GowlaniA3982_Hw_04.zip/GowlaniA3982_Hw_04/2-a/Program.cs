﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2_a
{
    class Program
    {
        static void Main(string[] args)
        {
            //3 numbers
            //for (int a = 1; a <= 5; a++)
            //{
            //    for (int b = a + 1; b <= 5; b++)
            //    {
            //        for (int c = b + 1; c <= 5; c++)
            //        {

            //            Console.WriteLine(a + " " + b + " " + c + " ");


            //        }
            //    }
            //}
            //4 numbers
            for (int a = 1; a <= 5; a++)
            {
                for (int b = a + 1; b <= 5; b++)
                {
                    for (int c = b + 1; c <= 5; c++)
                    {
                        for(int d=c+1;d<=5;d++)
                        {
                            Console.WriteLine(a + " " + b + " " + c + " "+ d+" ");
                        }
                        


                    }
                }
            }
        }
    }
}
