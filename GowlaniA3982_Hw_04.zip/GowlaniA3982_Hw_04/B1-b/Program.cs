﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B1_b
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;
            for (int a = 1; a <= 5; a++)
            {
                for (int b = 1; b <= 5; b++)
                {
                    for (int c = 1; c <= 5; c++)
                    {
                        if (a != b && a != c && b != c)
                        {
                            Console.WriteLine(a + " " + b + " " + c + " ");
                            sum = sum + (a * b * c);
                        }

                    }
                }
            }
            Console.WriteLine("the sum is:" + sum);
            //for (int a = 1; a <= 5; a++)
            //{
            //    for (int b = a+1; b <= 5; b++)
            //    {
            //        for (int c = b+1; c <= 5; c++)
            //        {

            //                Console.WriteLine(a + " " + b + " " + c + " ");


            //        }
            //    }
            //}
        }
    }
}
