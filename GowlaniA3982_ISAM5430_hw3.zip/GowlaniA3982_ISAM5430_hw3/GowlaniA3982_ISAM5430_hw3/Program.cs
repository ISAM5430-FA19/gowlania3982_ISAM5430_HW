﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GowlaniA3982_ISAM5430_hw3
{
    class Program
    {
        static void Main(string[] args)
        {

        }
    }
}
