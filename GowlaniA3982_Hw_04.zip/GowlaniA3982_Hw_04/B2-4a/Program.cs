﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2_4a
{
    class Program
    {
        static void Main(string[] args)
        {
            for(char a='A';a<='H';a++)
            {
                for(char b='A';b<='H';b++)
                {
                    for(char c='A';c<='H';c++)
                    {
                        if (a == 'A' || a =='E'||b=='A'||b=='E'||c=='A'||c=='E')
                        {
                            WriteLine(a + " " + b + " " + c + " ");
                        }
                       
                    }
                }
            }
        }
    }
}
