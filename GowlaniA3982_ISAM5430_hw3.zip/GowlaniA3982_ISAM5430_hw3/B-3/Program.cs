﻿using System;
using static System.Console;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B_3
{
    class Program
    {
        static void Main(string[] args)
        {
            WriteLine("enter the integers:");
            string n = ReadLine();
            int prevnum;
            prevnum =Convert.ToInt32( n);
           
           

            while (true)
            {
                 n =ReadLine();
                
               

                if (n==null)
                {
                    break;
                }
                else if(Convert.ToInt32(n) < prevnum)
                {
                    WriteLine("please enter in increasing order");
                    break;
                   


                }
               

            }
            WriteLine(prevnum);



        }
    }
}
